# 📚 👩‍💻 TCC - Grupo 4

## ProjetosDrugDrug 💊

## 💻 prototipação de tela

### 💥 Splash Screen
<img src="https://user-images.githubusercontent.com/83253328/165187028-35ecbb18-4560-4e95-8295-3bf5c68ace76.png" width="400" height="790">

### ✔ Tela de Login
<img src="https://user-images.githubusercontent.com/83253328/165187549-c6f77fab-69d5-4886-8ab8-d16e2d690495.png" width="400" height="790">
  
### 📋 Tela de Cadastro
<img src= "https://user-images.githubusercontent.com/83253328/165188950-e34fc186-c9fa-4523-a738-07e1c31c473d.png" width="400" height="790">

### 📳 Tela Principal
<img src= "https://user-images.githubusercontent.com/83253328/165191687-14a8ed82-a7d1-4061-a8fb-328ea55fd544.png" width="400" height="790">

### 📑 Tela de Menu
<img src= "https://user-images.githubusercontent.com/83253328/165191780-5ee6fbe5-eb25-460d-ad6c-e522d91581ea.png" width="200" height="600">

### ➕ Tela de Adicionar Lembrete
<img src= "https://user-images.githubusercontent.com/83253328/165191968-1a6e5379-60a8-4669-bb74-6585373dfa4c.png" width="400" height="790">

### 📴Tela de Histórico
<img src= "https://user-images.githubusercontent.com/83253328/165192173-4d67c11d-4d71-4eaa-b8df-e721b2db5723.png" width="400" height="790">
