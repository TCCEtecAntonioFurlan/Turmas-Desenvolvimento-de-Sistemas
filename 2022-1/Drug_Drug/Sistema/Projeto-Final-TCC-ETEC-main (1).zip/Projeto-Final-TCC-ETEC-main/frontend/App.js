import Rotas from './src/Rotas';

//Definindo o arquivo de Rotas como 'main'
const App = () => <Rotas/>;

export default App;

