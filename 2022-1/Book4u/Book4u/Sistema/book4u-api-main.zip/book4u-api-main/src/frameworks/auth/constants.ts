
export const jwtConstants = {
    secret: process.env.SECRET_KEY
};