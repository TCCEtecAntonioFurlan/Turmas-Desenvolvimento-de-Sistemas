export enum ExchangeSituation {
    CONFIRMADO = "Confirmado",
    PENDENTE = "Pendente",
    RECUSADO = "Recusado",
    ENTREGUE = "Entregue"
}