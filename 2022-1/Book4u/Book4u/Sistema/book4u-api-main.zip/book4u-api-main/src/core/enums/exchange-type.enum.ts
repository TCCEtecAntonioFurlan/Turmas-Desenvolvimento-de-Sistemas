export enum ExchangeType {
  PONTOS = "PONTOS",
  LIVRO = "LIVRO",
}
