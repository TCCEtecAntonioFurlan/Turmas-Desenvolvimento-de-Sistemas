export class PersonalData {
  cpf: string;
  cellphone: string;
  telephone: string;
  email: string;
  password: string;
  token: string;
  streetName: string;
  complement: string;
  district: string;
  houseNumber: string;
  zipCode: string;
  city: string;
  state: string;
}
