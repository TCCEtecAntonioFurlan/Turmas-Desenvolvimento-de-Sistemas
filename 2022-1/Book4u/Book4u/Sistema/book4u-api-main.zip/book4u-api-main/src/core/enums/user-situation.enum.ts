export const EnumUserSituation = {
    PENDENTE: 'Pendente',
    CONFIRMADO: 'Confirmado'
};