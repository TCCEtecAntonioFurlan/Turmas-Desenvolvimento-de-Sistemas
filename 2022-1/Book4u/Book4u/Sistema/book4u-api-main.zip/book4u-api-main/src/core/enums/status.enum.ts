export enum Status {
  DISPONIVEL = 'Disponível',
  INDISPONIVEL = 'Indisponível',
}
