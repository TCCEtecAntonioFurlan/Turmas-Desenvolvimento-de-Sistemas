export class ReadNotificationsDto {
    ids: []
}