export class Author {
  name: string;
}
