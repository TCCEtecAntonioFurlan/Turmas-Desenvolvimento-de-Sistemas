export class Publisher {
  name: string;
}
