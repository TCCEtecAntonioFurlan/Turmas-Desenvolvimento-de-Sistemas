export enum ReadNotification {
    READ = "Read",
    NONREAD = "Nonread"
}