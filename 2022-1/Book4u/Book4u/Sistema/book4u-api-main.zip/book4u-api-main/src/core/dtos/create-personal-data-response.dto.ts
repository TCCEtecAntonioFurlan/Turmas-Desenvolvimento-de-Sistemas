export class PartialResponse {
  success: boolean;
}
