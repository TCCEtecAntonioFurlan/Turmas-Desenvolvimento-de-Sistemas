export enum Condition {
  NOVO = 'Novo',
  SEMI_NOVO = 'Semi-novo',
  USADO = 'Usado',
}
