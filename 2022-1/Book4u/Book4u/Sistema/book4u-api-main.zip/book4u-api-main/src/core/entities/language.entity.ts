export class Language {
  name: string;
}
