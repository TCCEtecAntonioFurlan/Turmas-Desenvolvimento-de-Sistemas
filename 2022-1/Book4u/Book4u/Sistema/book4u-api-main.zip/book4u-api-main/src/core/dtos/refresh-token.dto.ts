export class RefreshTokenDto {
    token: string;
}