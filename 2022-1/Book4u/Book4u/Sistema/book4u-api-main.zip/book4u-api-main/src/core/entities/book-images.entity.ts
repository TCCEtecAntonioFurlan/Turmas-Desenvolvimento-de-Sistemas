export class BookImages {
    frontSideImage: string;
    rightSideImage: string;
    leftSideImage: string;
    backSideImage: string;
}
