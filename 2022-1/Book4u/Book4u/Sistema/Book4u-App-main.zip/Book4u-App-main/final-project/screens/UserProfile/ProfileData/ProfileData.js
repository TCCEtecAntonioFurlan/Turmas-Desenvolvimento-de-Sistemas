import { StyleSheet, Text, View, Dimensions, Pressable } from 'react-native';
import { useEffect, useState, useContext } from 'react';
import { Divider, Avatar } from 'react-native-paper';
import { AuthContext } from '../../../store/auth-context';
import { launchImageLibraryAsync } from 'expo-image-picker';

import { Colors } from '../../../constants/styles';

import IconBtn from '../../../componnets/UI/IconBtn';
import FlatButton from '../../../componnets/UI/FlatButton';
import UserBookSection from '../../../componnets/ProfileData/UserLibrarie/UserBookSection';
import TextIcon from '../../../componnets/UI/TextIcon';
import UserAddressForm from '../../../componnets/ProfileData/UserAddressForm';
import CellphoneForm from '../../../componnets/ProfileData/CellphoneForm';
import TelephoneForm from '../../../componnets/ProfileData/TelephoneForm';
import UserModal from '../../../componnets/ProfileData/UserModal';
import UserWishBookSection from '../../../componnets/ProfileData/UserLibrarie/UserWishBookSection';

import {
   sendUserCellphone,
   sendUserTelephone,
   sendUserAddress,
   sendUserProfilePicture,
   fetchUserLibrarie,
} from '../../../store/redux-store/user/user-actions';
import { setExternalUserData } from '../../../store/redux-store/externalUser/externalUser-actions';

import { useSelector, useDispatch } from 'react-redux';
import BookSelectInformation from '../../../componnets/BooksSection/BookSelectInformation';

const { width, height } = Dimensions.get('window');
const DEFAULT_STATE = 'Estado não cadastrado';
const DEFAULT_CITY = 'Cidade não cadastrada';
const DEFAULT_ADDRESS = 'Cidade não cadastrada';
const DEFAULT_USER_IMG = require('../../../assets/userImg/userProfileDefault.png');

const ProfileData = ({ navigation }) => {
   const authCtx = useContext(AuthContext);
   const dispatch = useDispatch();

   const wishList = useSelector((state) => state.user.wishlist);
   const userData = useSelector((state) => state.user.userData);
   const userLibrarie = useSelector((state) => state.user.userLibrarie);
   const userImg =
      userData.picture === '' ? DEFAULT_USER_IMG : { uri: userData.picture };

   const [bookData, setBookData] = useState({});
   const [bookOption, setBookOption] = useState(true);
   const [hasNoBooks, setHasNoBooks] = useState(false);
   const [hasNoWishBooks, setHasNoWishBooks] = useState(false);
   const [whishOption, setWhishOption] = useState(false);
   const [contactOption, setContactOption] = useState(false);

   const [cellphoneIsVisible, setCellphoneIsVisible] = useState(false);
   const [telephoneIsVisible, setTelephoneIsVisible] = useState(false);
   const [addressIsVisible, setAddressIsVisible] = useState(false);

   const hideCellphoneModal = () => setCellphoneIsVisible(false);
   const hideTelephoneModal = () => setTelephoneIsVisible(false);
   const hideAddressModal = () => setAddressIsVisible(false);

   useEffect(() => {
      dispatch(setExternalUserData(userData));
      dispatch(fetchUserLibrarie(authCtx.token));
   }, [dispatch, userData]);

   useEffect(() => {
      if (userLibrarie.length === 0) {
         setHasNoBooks(true);
      } else {
         setHasNoBooks(false);
      }
   }, [userLibrarie]);

   useEffect(() => {
      if (wishList.length === 0) {
         setHasNoWishBooks(true);
      } else {
         setHasNoWishBooks(false);
      }
   }, [wishList]);

   function addressHandler() {
      setAddressIsVisible(true);
   }

   function cellphoneHandler() {
      setCellphoneIsVisible(true);
   }

   function telephoneHandler() {
      setTelephoneIsVisible(true);
   }

   function cellPhoneFormCloseHandler() {
      hideCellphoneModal();
   }
   function telephoneFormCloseHandler() {
      hideTelephoneModal();
   }
   function addressFormCloseHandler() {
      hideAddressModal();
   }

   function bookOptionHandler() {
      setBookOption(true);
      setWhishOption(false);
      setContactOption(false);
   }
   function whishOptionHandler() {
      setBookOption(false);
      setWhishOption(true);
      setContactOption(false);
   }
   function contactOptionHandler() {
      setBookOption(false);
      setWhishOption(false);
      setContactOption(true);
   }

   function addNewBookHandler() {
      navigation.navigate('RegisterBook');
   }
   function editBookHandler() {
      navigation.navigate('EditBook', {
         userBooks: userLibrarie,
      });
   }
   function deleteBookHandler() {
      navigation.navigate('DeleteBook');
   }

   async function submitAddressHandler(userAddress) {
      dispatch(sendUserAddress(authCtx.token, userAddress));
   }

   async function submitCellphoneHandler(userCellphone) {
      dispatch(sendUserCellphone(authCtx.token, userCellphone));
   }

   async function submitTelephoneHandler(userTelephone) {
      dispatch(sendUserTelephone(authCtx.token, userTelephone));
   }

   async function profilePictureHandler() {
      const image = await launchImageLibraryAsync({
         allowsEditing: true,
         aspect: [4, 6],
         quality: 1,
      });

      if (!image.cancelled) {
         const userPicture = { picture: image.uri };
         dispatch(sendUserProfilePicture(authCtx.token, userPicture));
      }
   }

   return (
      <>
         <View>
            <View style={styles.profileContainer}>
               <View style={styles.profileBackgroundImg}>
                  <View style={styles.profileWrapper}>
                     <Pressable onPress={profilePictureHandler}>
                        <Avatar.Image
                           size={120}
                           style={styles.profileBackgroundColor}
                           source={userImg}
                        />
                     </Pressable>

                     <Text style={[styles.text, styles.userText]}>
                        {userData.fullName}
                     </Text>
                     <Text style={[styles.text, styles.userState]}>
                        {userData.state === null
                           ? DEFAULT_STATE
                           : userData.state}
                     </Text>
                     <Text style={[styles.text, styles.userCity]}>
                        {userData.city === null ? DEFAULT_CITY : userData.city}
                     </Text>
                  </View>
               </View>
            </View>
            <View style={styles.profileOptionsContainer}>
               <View style={styles.profileOptionsWrapper}>
                  <View style={bookOption && styles.optionBorder}>
                     <FlatButton onPress={bookOptionHandler}>Livros</FlatButton>
                  </View>
                  <View style={whishOption && styles.optionBorder}>
                     <FlatButton onPress={whishOptionHandler}>
                        Lista de Desejos
                     </FlatButton>
                  </View>
                  <View style={contactOption && styles.optionBorder}>
                     <FlatButton onPress={contactOptionHandler}>
                        Contato
                     </FlatButton>
                  </View>
               </View>
               <Divider style={styles.divider} />
            </View>
            {bookOption && (
               <View style={styles.userLibrary}>
                  <View style={styles.userWishlist}>
                     <Text style={styles.userLibraryTitle}>
                        Minha biblioteca
                     </Text>
                     <IconBtn
                        icon='add-circle-outline'
                        size={24}
                        iconBtnStyle={styles.addWishlistIcon}
                        onPress={addNewBookHandler}
                     />
                     <IconBtn
                        icon='pencil-outline'
                        size={24}
                        iconBtnStyle={styles.addWishlistIcon}
                        onPress={editBookHandler}
                     />
                     <IconBtn
                        icon='trash-outline'
                        size={24}
                        iconBtnStyle={styles.addWishlistIcon}
                        onPress={deleteBookHandler}
                     />
                  </View>
                  <UserBookSection items={userLibrarie} />
                  {hasNoBooks && (
                     <BookSelectInformation
                        text={`Nenhum livro cadastrado no momento, cadastre um livro clicando no botão de '+'.`}
                     />
                  )}
               </View>
            )}
            {whishOption && (
               <View style={styles.userLibrary}>
                  <Text style={styles.userLibraryTitle}>
                     Minha lista de desejo
                  </Text>

                  <UserWishBookSection items={wishList} />
                  {hasNoWishBooks && (
                     <BookSelectInformation
                        text={`Nenhum favorito adicionado no momento, pesquise livros agora e adicione no ícone de coração !`}
                     />
                  )}
               </View>
            )}
            {contactOption && (
               <View style={styles.userLibrary}>
                  <TextIcon
                     text={userData.telephone}
                     textConfig={styles.textIconTextConfig}
                     leftIconConfig={{
                        name: 'call-outline',
                        size: 20,
                        color: Colors.silver200,
                     }}
                     iconBtnConfig={{
                        name: 'open-outline',
                        size: 20,
                        color: Colors.silver200,
                     }}
                     // iconBtnStyle={}
                     onIconBtnPress={telephoneHandler}
                  />
                  <TextIcon
                     text={userData.cellphone}
                     textConfig={styles.textIconTextConfig}
                     leftIconConfig={{
                        name: 'phone-portrait-outline',
                        size: 20,
                        color: Colors.silver200,
                     }}
                     iconBtnConfig={{
                        name: 'open-outline',
                        size: 20,
                        color: Colors.silver200,
                     }}
                     // iconBtnStyle={}
                     onIconBtnPress={cellphoneHandler}
                  />
                  <TextIcon
                     text={
                        userData.streetName === null
                           ? DEFAULT_ADDRESS
                           : userData.streetName
                     }
                     textConfig={styles.textIconTextConfig}
                     leftIconConfig={{
                        name: 'location-outline',
                        size: 20,
                        color: Colors.silver200,
                     }}
                     iconBtnConfig={{
                        name: 'open-outline',
                        size: 20,
                        color: Colors.silver200,
                     }}
                     // iconBtnStyle={}
                     onIconBtnPress={addressHandler}
                  />
               </View>
            )}
         </View>

         <UserModal
            onShow={addressIsVisible}
            onHideModal={hideAddressModal}
            formData={
               <UserAddressForm
                  onSubmit={submitAddressHandler}
                  onClose={addressFormCloseHandler}
               />
            }
         />
         <UserModal
            onShow={cellphoneIsVisible}
            onHideModal={hideCellphoneModal}
            formData={
               <CellphoneForm
                  onSubmit={submitCellphoneHandler}
                  onClose={cellPhoneFormCloseHandler}
               />
            }
            modalHeight={styles.modalWidth}
         />
         <UserModal
            onShow={telephoneIsVisible}
            onHideModal={hideTelephoneModal}
            formData={
               <TelephoneForm
                  onSubmit={submitTelephoneHandler}
                  onClose={telephoneFormCloseHandler}
               />
            }
            modalHeight={styles.modalWidth}
         />
      </>
   );
};

export default ProfileData;

const styles = StyleSheet.create({
   profileContainer: {
      position: 'relative',
   },
   profileWrapper: {
      alignItems: 'center',
      position: 'absolute',
      left: 0,
      right: 0,
      top: width / 4,
   },
   profileBackgroundImg: {
      backgroundColor: Colors.quartiary,
      width: '100%',
      height: width * 0.4,
   },
   profileBackgroundColor: {
      backgroundColor: Colors.snow,
      borderColor: Colors.silver300,
      elevation: 2,
      marginBottom: 12,
   },
   text: {
      fontFamily: 'lato-light',
      color: Colors.silver300,
   },
   userText: {
      fontSize: 24,
   },
   userState: {
      fontSize: 16,
      marginTop: 6,
   },
   userCity: {
      fontSize: 16,
      marginTop: 4,
   },
   profileOptionsContainer: {
      marginHorizontal: 30,
   },
   profileOptionsWrapper: {
      marginTop: width / 2,
      flexDirection: 'row',
      justifyContent: 'space-evenly',
   },
   profileOptionsText: {
      fontFamily: 'lato-regular',
      color: Colors.silver300,
   },
   divider: {
      height: 2,
      marginTop: 15,
   },
   userLibrary: {
      marginTop: 30,
      marginHorizontal: 30,
   },
   userLibraryTitle: {
      fontFamily: 'lato-bold',
      color: Colors.silver300,
   },
   optionBorder: {
      borderBottomWidth: 5,
      borderColor: Colors.secondary,
      borderRadius: 10,
   },
   textIconTextConfig: {
      fontFamily: 'lato-regular',
   },
   userWishlist: {
      flexDirection: 'row',
      alignItems: 'center',
   },
   addWishlistIcon: {
      color: Colors.secondary,
   },
   modalWidth: {
      marginTop: width * 1.2,
   },
});
